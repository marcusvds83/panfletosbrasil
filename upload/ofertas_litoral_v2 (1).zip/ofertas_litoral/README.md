# Ofertas do Litoral — App B2B v2

Plataforma B2B para divulgação de encartes de supermercados.
O mercado parceiro faz login, sobe o PDF do encarte, e a IA extrai produtos
automaticamente. O usuário final vê o PDF oficial e compara preços entre
mercados.

## Modelo de negócio

| Item | Valor |
|---|---|
| App para usuário final | **Gratuito** |
| Piloto para mercado | **60 dias grátis** |
| Mensalidade após piloto | **R$ 800/mês** |
| Ícone patrocinado na home | **R$ 2.000/mês** (máx. 20 mercados) |
| Anúncios no app | ❌ (sem propagandas) |

## Como rodar (Windows)

1. **Pré-requisito**: Python 3.10+ — https://www.python.org/downloads/windows/
   (marque "Add Python to PATH")
2. **Opcional** (para extração automática de PDF via IA): Node.js + CLI z-ai
   ```
   npm install -g z-ai-web-dev-sdk
   ```
   Sem isso, o mercado cadastra produtos manualmente após subir o PDF.
3. Descompacte o `.zip`.
4. Duplo clique em **`iniciar_app.bat`**.
5. Abre automaticamente em `http://127.0.0.1:5000`.

## Logins de demo

| Perfil | Email | Senha |
|---|---|---|
| Admin master | `admin@ofertasdo.litoral` | `admin123` |
| Mercado Dom Levi | `domlevi@exemplo.com` | `mercado123` |
| Mercado Quintetto | `quintetto@exemplo.com` | `mercado123` (destaque ativo) |

## Fluxos do app

### Usuário final (público)
- Abre o app → vê ícones de mercados patrocinadores (máx. 20) no topo
- Abaixo: lista de mercados em ordem aleatória
- Clica em mercado → vê PDF do encarte + lista de produtos
- Aba "Comparar preços" → itens equivalentes entre mercados

### Mercado parceiro (logado)
- Login → painel do mercado com stats (encartes, produtos, status)
- Upload de PDF → IA extrai produtos automaticamente
- Revisar/editar produtos extraídos
- Re-extrair se necessário

### Admin master (você)
- Painel com todos os mercados cadastrados
- Stats globais: total, em piloto, ativos, inativos, destaques, **receita mensal potencial**
- Cadastrar novo mercado (inicia piloto 60 dias automaticamente)
- Ativar/desativar destaque patrocinado
- Mudar status (piloto → ativo → inativo)
- Excluir mercado

## Estrutura de pastas

```
ofertas_litoral/
├── iniciar_app.bat          ← double-click para iniciar
├── app.py                   ← servidor Flask (API + rotas + auth)
├── extractor.py             ← extrai produtos do PDF via IA (z-ai vision)
├── seed.py                  ← dados de exemplo (2 mercados demo)
├── requirements.txt         ← Flask + PyMuPDF + Werkzeug
├── .env.example             ← modelo de configuração
├── email_odoo_piloto.txt    ← template HTML de email para Odoo
├── README.md                ← este arquivo
├── templates/
│   └── index.html
├── static/
│   ├── css/style.css
│   ├── js/app.js
│   └── pdfs/                ← PDFs dos encartes (Dom Levi + Quintetto)
├── data/                    ← banco SQLite (criado em runtime)
└── uploads/                 ← PDFs novos enviados pelos mercados
```

## Endpoints da API

### Públicos
| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/mercados` | Lista mercados (destaques + normais) |
| GET | `/api/mercado/<id>` | Detalhe + produtos + encartes |
| GET | `/api/comparar` | Comparativo de preços |

### Auth
| Método | Rota | Descrição |
|---|---|---|
| POST | `/api/auth/login` | Login (mercado ou admin) |
| POST | `/api/auth/logout` | Logout |
| GET | `/api/auth/eu` | Sessão atual |

### Mercado logado
| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/mercado/conta` | Dados do mercado logado |
| POST | `/api/mercado/encarte` | Upload de PDF (extrai IA) |
| POST | `/api/mercado/encarte/<id>/reextrair` | Re-extrair produtos |
| GET/POST/DELETE | `/api/mercado/encarte/<id>/produtos` | CRUD produtos |

### Admin master
| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/admin/mercados` | Lista todos |
| POST | `/api/admin/mercado` | Cria mercado (piloto 60 dias) |
| DELETE | `/api/admin/mercado/<id>` | Remove |
| POST | `/api/admin/destaque/<id>` | Ativa/desativa destaque |
| POST | `/api/admin/status/<id>` | Muda status |
| POST | `/api/admin/seed` | Recarrega dados demo |

## Próximos passos (escala nacional)

1. **Disparar email marketing via Odoo** — usar `email_odoo_piloto.txt` e a lista
   `contatos_supermercados_brasil.xlsx` (39 supermercados, 29 com email público).
2. **Subir backend para produção** — recommended: Render/Railway/Vercel +
   PostgreSQL (substituir SQLite).
3. **App mobile (Play Store / Apple Store)** — React Native ou Flutter
   consumindo a mesma API. Recomendação: **Expo + React Native** para lançar
   nas duas lojas com um único codebase.
4. **Integração de pagamentos** — Stripe ou Mercado Pago para cobrança
   recorrente da mensalidade R$800 e do destaque R$2000.
5. **Geolocalização real** — Google Maps API ou Mapbox para "mercado mais próximo".
6. **Painel de métricas para mercados** — visualizações, cliques, conversões.

## Observação

Preços, estoque e validade são responsabilidade de cada mercado.
Este protótipo é para validação local — para produção, substituir:
- SQLite → PostgreSQL
- Sessões Flask → JWT
- `.env` simples → secrets manager
- CLI z-ai → chamada direta à API de IA em backend
