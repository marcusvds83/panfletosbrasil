"""
Seed v2 — popula o banco com os 2 encartes de exemplo e usuários de login.

Logins criados:
  Admin master:   admin@ofertasdo.litoral / admin123
  Mercado Dom Levi:    domlevi@exemplo.com / mercado123
  Mercado Quintetto:   quintetto@exemplo.com / mercado123
"""
import sqlite3
from pathlib import Path
from werkzeug.security import generate_password_hash
from app import DB_PATH, normalizar_produto, hoje, data_futura, PILOTO_DIAS, MENSALIDADE_BASE

BASE_DIR = Path(__file__).resolve().parent


MERCADOS_EXEMPLO = [
    {
        "nome": "Dom Levi Supermercado",
        "cidade": "Pontal do Paraná",
        "estado": "PR",
        "endereco": "Av. Brasil, s/n — Centro (a confirmar)",
        "telefone": "(41) 98411-9267",
        "latitude": -25.6605,
        "longitude": -48.5217,
        "email_login": "domlevi@exemplo.com",
        "destaque": 0,
        "encarte": {
            "titulo": "Encarte Dom Levi — Julho 2026",
            "pdf_path": "domlevi1pdf.pdf",
            "data_inicio": "10/07/2026",
            "data_fim": "",
        },
        "produtos": [
            {"nome": "Queijo Mussarela", "marca": "", "preco": "39,90", "unidade": "kg"},
            {"nome": "Presunto", "marca": "", "preco": "23,99", "unidade": "kg"},
            {"nome": "Massa de Pizza", "marca": "Trindade", "preco": "4,99", "unidade": "200g"},
            {"nome": "Massa de Pizza Semi-Pronta", "marca": "Dom Levi", "preco": "4,99", "unidade": "200g"},
            {"nome": "Pizza Cogumelos", "marca": "Seara", "preco": "14,99", "unidade": "460g"},
            {"nome": "Pizza Cogumelos", "marca": "Aurora", "preco": "14,99", "unidade": "460g"},
            {"nome": "Arroz Parboilizado", "marca": "Tio João", "preco": "4,19", "unidade": "kg"},
            {"nome": "Cerveja Puro Malte", "marca": "Spaten", "preco": "4,79", "unidade": "350ml"},
        ],
    },
    {
        "nome": "Quintetto Supermercados",
        "cidade": "Matinhos",
        "estado": "PR",
        "endereco": "Av. Curitiba, 1450 — Centro (a confirmar)",
        "telefone": "",
        "latitude": -25.8167,
        "longitude": -48.5444,
        "email_login": "quintetto@exemplo.com",
        "destaque": 1,  # exemplo de mercado patrocinador
        "encarte": {
            "titulo": "Encarte Quintetto — 08 a 12/07/2026",
            "pdf_path": "quintetto1pdf.pdf",
            "data_inicio": "08/07/2026",
            "data_fim": "12/07/2026",
        },
        "produtos": [
            {"nome": "Farinha de Trigo", "marca": "Orquidea", "preco": "4,39", "unidade": "kg"},
            {"nome": "Arroz Parboilizado", "marca": "Urbano", "preco": "3,69", "unidade": "kg"},
            {"nome": "Açúcar Refinado", "marca": "Da Barra", "preco": "3,85", "unidade": "kg"},
            {"nome": "Feijão Preto", "marca": "Pê Vermelho", "preco": "5,98", "unidade": "kg"},
            {"nome": "Molho de Tomate", "marca": "Predilecta", "preco": "1,45", "unidade": "saco"},
            {"nome": "Café", "marca": "Damasco", "preco": "22,95", "unidade": "500g"},
            {"nome": "Farofa de Mandioca", "marca": "Pinduca", "preco": "3,99", "unidade": "250g"},
            {"nome": "Arroz Integral", "marca": "Mix Completo", "preco": "5,65", "unidade": "kg"},
            {"nome": "Macarrão Caseiro", "marca": "Turelli", "preco": "6,45", "unidade": "500g"},
            {"nome": "Polenta", "marca": "Polentina", "preco": "3,99", "unidade": "500g"},
            {"nome": "Suco em Pó", "marca": "Tang", "preco": "1,15", "unidade": "18g"},
            {"nome": "Papel Higiênico Folha Dupla", "marca": "Suavita Premium", "preco": "11,95", "unidade": "12un"},
            {"nome": "Desinfetante", "marca": "Super Clean", "preco": "6,98", "unidade": "2L"},
            {"nome": "Lava Roupas Líquido", "marca": "Omo Boom", "preco": "14,95", "unidade": "1L"},
            {"nome": "Limpa Geral", "marca": "Casa e Perfume", "preco": "5,65", "unidade": "500ml"},
            {"nome": "Amaciante", "marca": "Baby Soft", "preco": "6,99", "unidade": "2L"},
            {"nome": "Refrigerante", "marca": "Cini", "preco": "4,69", "unidade": "2L"},
            {"nome": "Aguardente", "marca": "Barreiro Hófer", "preco": "14,95", "unidade": "910ml"},
            {"nome": "Vinho Nacional", "marca": "Sangue de Boi", "preco": "13,98", "unidade": "750ml"},
            {"nome": "Vodka", "marca": "Askov", "preco": "15,75", "unidade": "900ml"},
            {"nome": "Cerveja Puro Malte", "marca": "Spaten", "preco": "4,89", "unidade": "350ml"},
        ],
    },
]


def run_seed(force: bool = False):
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    if force:
        cur.executescript(
            "DELETE FROM produtos; DELETE FROM encartes; DELETE FROM mercados;"
        )
        conn.commit()

    hoje_str = hoje()
    piloto_fim = data_futura(PILOTO_DIAS)

    for m in MERCADOS_EXEMPLO:
        # Verifica se já existe por email_login
        row = cur.execute(
            "SELECT id FROM mercados WHERE email_login=?", (m["email_login"],)
        ).fetchone()
        if row:
            mid = row["id"]
            cur.execute(
                """UPDATE mercados SET nome=?, cidade=?, estado=?, endereco=?, telefone=?,
                   latitude=?, longitude=?, destaque=?,
                   piloto_inicio=?, piloto_fim=?, mensalidade=?, status='piloto'
                   WHERE id=?""",
                (m["nome"], m["cidade"], m["estado"], m["endereco"], m["telefone"],
                 m["latitude"], m["longitude"], m["destaque"],
                 hoje_str, piloto_fim, MENSALIDADE_BASE, mid),
            )
        else:
            cur.execute(
                """INSERT INTO mercados
                   (nome, cidade, estado, endereco, telefone, latitude, longitude,
                    email_login, senha_hash, destaque, destaque_inicio, destaque_fim,
                    piloto_inicio, piloto_fim, mensalidade, status)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'piloto')""",
                (m["nome"], m["cidade"], m["estado"], m["endereco"], m["telefone"],
                 m["latitude"], m["longitude"], m["email_login"],
                 generate_password_hash("mercado123"),
                 m["destaque"],
                 # Se destaque, vigente por 30 dias a partir de hoje
                 hoje_str if m["destaque"] else None,
                 data_futura(30) if m["destaque"] else None,
                 hoje_str, piloto_fim, MENSALIDADE_BASE),
            )
            mid = cur.lastrowid

        # Encarte
        e = m["encarte"]
        erow = cur.execute(
            "SELECT id FROM encartes WHERE mercado_id=? AND pdf_path=?",
            (mid, e["pdf_path"]),
        ).fetchone()
        if erow:
            eid = erow["id"]
            cur.execute(
                "UPDATE encartes SET titulo=?, data_inicio=?, data_fim=?, status_extracao='concluido' WHERE id=?",
                (e["titulo"], e["data_inicio"], e["data_fim"], eid),
            )
        else:
            cur.execute(
                """INSERT INTO encartes (mercado_id, titulo, pdf_path, data_inicio, data_fim, status_extracao)
                   VALUES (?,?,?,?,?, 'concluido')""",
                (mid, e["titulo"], e["pdf_path"], e["data_inicio"], e["data_fim"]),
            )
            eid = cur.lastrowid

        # Produtos
        cur.execute("DELETE FROM produtos WHERE encarte_id=?", (eid,))
        for p in m["produtos"]:
            norm = normalizar_produto(p["nome"], p.get("marca", ""), p.get("unidade", ""))
            cur.execute(
                """INSERT INTO produtos (encarte_id, mercado_id, nome, marca, preco, unidade, normalizado)
                   VALUES (?,?,?,?,?,?,?)""",
                (eid, mid, p["nome"], p.get("marca", ""), p["preco"], p.get("unidade", ""), norm),
            )

    conn.commit()
    conn.close()
    print(f"Seed v2 concluído: 2 mercados de exemplo + logins criados.")
    print(f"  Admin:   admin@ofertasdo.litoral / admin123")
    print(f"  Dom Levi:    domlevi@exemplo.com / mercado123")
    print(f"  Quintetto:   quintetto@exemplo.com / mercado123 (destaque ativo)")


if __name__ == "__main__":
    run_seed(force=True)
