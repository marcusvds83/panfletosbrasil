"""
Ofertas do Litoral — App B2B v2
Servidor Flask com:
  - Login de mercado (sessão)
  - Upload de PDF pelo próprio mercado
  - Auto-extração de produtos via IA (z-ai vision CLI)
  - Ícones pagos na home (máx. 20 destaques)
  - Gestão de piloto (60 dias grátis → R$800/mês)
  - Painel admin master (você) e painel do mercado

Uso:
    python app.py
Acesse:
    http://127.0.0.1:5000
"""

import os
import sqlite3
import random
import json
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from datetime import datetime, timedelta
from flask import (
    Flask, request, jsonify, send_from_directory, render_template,
    abort, session, redirect, url_for, flash
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

# ---------------------------------------------------------------------------
# Configuração
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "mercados.db"
PDF_DIR = BASE_DIR / "static" / "pdfs"
UPLOAD_DIR = BASE_DIR / "uploads"
DATA_DIR = BASE_DIR / "data"

for p in (DATA_DIR, PDF_DIR, UPLOAD_DIR):
    p.mkdir(parents=True, exist_ok=True)

# Carrega .env (sem dependência externa)
ENV_FILE = BASE_DIR / ".env"
if ENV_FILE.exists():
    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

APP_HOST = os.environ.get("APP_HOST", "127.0.0.1")
APP_PORT = int(os.environ.get("APP_PORT", "5000"))
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "admin-local")
SECRET_KEY = os.environ.get("SECRET_KEY", "trocar-em-producao-2026")
PILOTO_DIAS = int(os.environ.get("PILOTO_DIAS", "60"))
MENSALIDADE_BASE = float(os.environ.get("MENSALIDADE_BASE", "800"))
DESTAQUE_MENSAL = float(os.environ.get("DESTAQUE_MENSAL", "2000"))
MAX_DESTAQUES = int(os.environ.get("MAX_DESTAQUES", "20"))
# Caminho para o CLI z-ai (deixe vazio para desabilitar extração automática)
ZAI_CLI = os.environ.get("ZAI_CLI", "z-ai")

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024
app.secret_key = SECRET_KEY


# ---------------------------------------------------------------------------
# Banco de dados
# ---------------------------------------------------------------------------
def get_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.executescript(
        """
        CREATE TABLE IF NOT EXISTS mercados (
            id                INTEGER PRIMARY KEY AUTOINCREMENT,
            nome              TEXT NOT NULL,
            cidade            TEXT,
            estado            TEXT,
            endereco          TEXT,
            telefone          TEXT,
            latitude          REAL,
            longitude         REAL,
            email_login       TEXT UNIQUE,
            senha_hash        TEXT,
            logo_path         TEXT,
            destaque          INTEGER DEFAULT 0,
            destaque_inicio   TEXT,
            destaque_fim      TEXT,
            piloto_inicio     TEXT,
            piloto_fim        TEXT,
            mensalidade       REAL DEFAULT 800,
            status            TEXT DEFAULT 'piloto',  -- piloto | ativo | inativo
            criado_em         TEXT DEFAULT (datetime('now','localtime'))
        );

        CREATE TABLE IF NOT EXISTS encartes (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            mercado_id       INTEGER NOT NULL,
            titulo           TEXT,
            pdf_path         TEXT NOT NULL,
            data_inicio      TEXT,
            data_fim         TEXT,
            status_extracao  TEXT DEFAULT 'pendente', -- pendente | processando | concluido | erro
            extracao_log     TEXT,
            criado_em        TEXT DEFAULT (datetime('now','localtime')),
            FOREIGN KEY (mercado_id) REFERENCES mercados(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS produtos (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            encarte_id  INTEGER NOT NULL,
            mercado_id  INTEGER NOT NULL,
            nome        TEXT NOT NULL,
            marca       TEXT,
            preco       TEXT NOT NULL,
            unidade     TEXT,
            normalizado TEXT,
            FOREIGN KEY (encarte_id) REFERENCES encartes(id) ON DELETE CASCADE,
            FOREIGN KEY (mercado_id) REFERENCES mercados(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS admin_master (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            email_login  TEXT UNIQUE,
            senha_hash   TEXT
        );
        """
    )
    # Admin master padrão (caso não exista)
    row = conn.execute("SELECT id FROM admin_master WHERE email_login=?", ("admin@ofertasdo.litoral",)).fetchone()
    if not row:
        conn.execute(
            "INSERT INTO admin_master (email_login, senha_hash) VALUES (?, ?)",
            ("admin@ofertasdo.litoral", generate_password_hash("admin123")),
        )
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------
def normalizar_produto(nome: str, marca: str, unidade: str) -> str:
    """Chave normalizada para comparar produtos equivalentes (ignora marca)."""
    txt = (nome or "").lower()
    txt = txt.replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u")
    txt = txt.replace("ã", "a").replace("õ", "o").replace("ç", "c").replace("â", "a").replace("ê", "e").replace("ô", "o")
    txt = re.sub(r"[^a-z0-9 ]+", " ", txt)
    txt = re.sub(r"\s+", " ", txt).strip()
    uni = (unidade or "").lower().replace(" ", "")
    uni = re.sub(r"[^a-z0-9]", "", uni)
    if uni in ("kg", "kilo", "quilos"):
        uni = "kg"
    elif uni in ("g", "gramas"):
        uni = "g"
    elif uni in ("l", "litro", "litros"):
        uni = "l"
    elif uni in ("ml", "mililitro"):
        uni = "ml"
    elif uni.startswith("un"):
        uni = "un"
    return f"{txt}|{uni}"


def parse_preco(preco: str) -> float:
    if not preco:
        return 0.0
    s = re.sub(r"[^\d,\.]", "", str(preco))
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return 0.0


def rows_to_dict(rows):
    return [dict(r) for r in rows]


def requer_admin_master():
    return session.get("tipo") == "admin_master"


def requer_mercado_logado():
    return session.get("tipo") == "mercado"


def hoje():
    return datetime.now().strftime("%Y-%m-%d")


def data_futura(dias: int) -> str:
    return (datetime.now() + timedelta(days=dias)).strftime("%Y-%m-%d")


def status_piloto(m):
    """Calcula status efetivo do mercado com base nas datas."""
    if not m:
        return "inativo"
    if m["status"] == "inativo":
        return "inativo"
    pfim = m["piloto_fim"]
    if pfim and pfim < hoje():
        return "piloto_expirado"
    return m["status"]


# ---------------------------------------------------------------------------
# Rotas de interface
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/static/pdfs/<path:filename>")
def pdfs(filename):
    return send_from_directory(str(PDF_DIR), filename)


@app.route("/static/logos/<path:filename>")
def logos(filename):
    return send_from_directory(str(BASE_DIR / "static" / "logos"), filename)


# ---------------------------------------------------------------------------
# API pública (consumida pelo app mobile/web do usuário final)
# ---------------------------------------------------------------------------
@app.route("/api/mercados")
def api_mercados():
    """Lista mercados. Destaques ativos no topo (máx 20), depois aleatório."""
    conn = get_db()
    hoje_str = hoje()
    rows = conn.execute(
        """SELECT id, nome, cidade, estado, endereco, telefone, logo_path,
                  destaque, destaque_inicio, destaque_fim, status
           FROM mercados
           WHERE status != 'inativo'
           ORDER BY nome"""
    ).fetchall()
    conn.close()

    lista = rows_to_dict(rows)
    destaques = []
    normais = []
    for m in lista:
        # Verifica se destaque está vigente
        if m["destaque"] and m["destaque_inicio"] and m["destaque_fim"]:
            if m["destaque_inicio"] <= hoje_str <= m["destaque_fim"]:
                destaques.append(m)
                continue
        normais.append(m)

    random.shuffle(normais)
    # Limite máximo de destaques na home
    destaques = destaques[:MAX_DESTAQUES]
    return jsonify({"destaques": destaques, "mercados": normais})


@app.route("/api/mercado/<int:mid>")
def api_mercado_detalhe(mid):
    conn = get_db()
    mercado = conn.execute("SELECT * FROM mercados WHERE id=?", (mid,)).fetchone()
    if not mercado:
        conn.close()
        abort(404)
    encartes = conn.execute(
        "SELECT * FROM encartes WHERE mercado_id=? ORDER BY id DESC", (mid,)
    ).fetchall()
    produtos = conn.execute(
        "SELECT * FROM produtos WHERE mercado_id=? ORDER BY nome", (mid,)
    ).fetchall()
    conn.close()
    return jsonify(
        {
            "mercado": dict(mercado),
            "encartes": rows_to_dict(encartes),
            "produtos": rows_to_dict(produtos),
        }
    )


@app.route("/api/comparar")
def api_comparar():
    conn = get_db()
    produtos = conn.execute(
        """
        SELECT p.id, p.nome, p.marca, p.preco, p.unidade, p.normalizado,
               p.mercado_id, m.nome AS mercado_nome, m.cidade AS mercado_cidade
        FROM produtos p
        JOIN mercados m ON m.id = p.mercado_id
        WHERE m.status != 'inativo'
        ORDER BY p.normalizado, p.nome
        """
    ).fetchall()
    conn.close()
    grupos = {}
    for p in produtos:
        chave = p["normalizado"] or normalizar_produto(p["nome"], p["marca"], p["unidade"])
        grupos.setdefault(chave, []).append(dict(p))
    comparativo = []
    for chave, items in grupos.items():
        mercados_distintos = {i["mercado_id"] for i in items}
        if len(mercados_distintos) < 2:
            continue
        items.sort(key=lambda x: parse_preco(x["preco"]))
        comparativo.append(
            {
                "produto": items[0]["nome"],
                "marca": items[0]["marca"],
                "unidade": items[0]["unidade"],
                "mais_barato": items[0],
                "opcoes": items,
            }
        )
    return jsonify(comparativo)


# ---------------------------------------------------------------------------
# Auth (login mercado e admin master)
# ---------------------------------------------------------------------------
@app.route("/api/auth/login", methods=["POST"])
def auth_login():
    d = request.json or {}
    email = (d.get("email") or "").strip().lower()
    senha = d.get("senha") or ""
    if not email or not senha:
        return jsonify({"erro": "Email e senha são obrigatórios"}), 400

    conn = get_db()
    # Tenta admin master primeiro
    admin = conn.execute(
        "SELECT * FROM admin_master WHERE email_login=?", (email,)
    ).fetchone()
    if admin and check_password_hash(admin["senha_hash"], senha):
        session.clear()
        session["tipo"] = "admin_master"
        session["email"] = email
        conn.close()
        return jsonify({"ok": True, "tipo": "admin_master", "email": email})

    # Depois mercado
    m = conn.execute(
        "SELECT * FROM mercados WHERE email_login=?", (email,)
    ).fetchone()
    if m and m["senha_hash"] and check_password_hash(m["senha_hash"], senha):
        session.clear()
        session["tipo"] = "mercado"
        session["mercado_id"] = m["id"]
        session["email"] = email
        conn.close()
        return jsonify({"ok": True, "tipo": "mercado", "mercado_id": m["id"], "email": email})

    conn.close()
    return jsonify({"erro": "Email ou senha inválidos"}), 401


@app.route("/api/auth/logout", methods=["POST"])
def auth_logout():
    session.clear()
    return jsonify({"ok": True})


@app.route("/api/auth/eu")
def auth_eu():
    return jsonify({
        "tipo": session.get("tipo"),
        "mercado_id": session.get("mercado_id"),
        "email": session.get("email"),
    })


# ---------------------------------------------------------------------------
# Painel do MERCADO (logado)
# ---------------------------------------------------------------------------
@app.route("/api/mercado/conta")
def mercado_conta():
    if not requer_mercado_logado():
        return jsonify({"erro": "Não autenticado"}), 401
    mid = session["mercado_id"]
    conn = get_db()
    m = conn.execute("SELECT * FROM mercados WHERE id=?", (mid,)).fetchone()
    encartes = conn.execute(
        "SELECT * FROM encartes WHERE mercado_id=? ORDER BY id DESC", (mid,)
    ).fetchall()
    produtos_count = conn.execute(
        "SELECT COUNT(*) as c FROM produtos WHERE mercado_id=?", (mid,)
    ).fetchone()
    conn.close()
    if not m:
        return jsonify({"erro": "Mercado não encontrado"}), 404
    return jsonify({
        "mercado": dict(m),
        "encartes": rows_to_dict(encartes),
        "total_produtos": produtos_count["c"],
        "status_efetivo": status_piloto(m),
    })


@app.route("/api/mercado/encarte", methods=["POST"])
def mercado_upload_encarte():
    """Mercado faz upload de PDF. Extração é disparada automaticamente."""
    if not requer_mercado_logado():
        return jsonify({"erro": "Não autenticado"}), 401
    mid = session["mercado_id"]

    titulo = request.form.get("titulo", "")
    data_inicio = request.form.get("data_inicio", "")
    data_fim = request.form.get("data_fim", "")

    if "pdf" not in request.files:
        return jsonify({"erro": "PDF é obrigatório"}), 400
    f = request.files["pdf"]
    if not f.filename.lower().endswith(".pdf"):
        return jsonify({"erro": "Arquivo deve ser PDF"}), 400

    nome_seguro = secure_filename(f.filename)
    if not nome_seguro:
        nome_seguro = f"encarte_{int(time.time())}.pdf"
    # Prefixa com ID do mercado para evitar colisão
    nome_seguro = f"m{mid}_{nome_seguro}"
    destino = PDF_DIR / nome_seguro
    f.save(str(destino))

    conn = get_db()
    cur = conn.execute(
        """INSERT INTO encartes (mercado_id, titulo, pdf_path, data_inicio, data_fim, status_extracao)
           VALUES (?,?,?,?,?, 'pendente')""",
        (mid, titulo, nome_seguro, data_inicio, data_fim),
    )
    eid = cur.lastrowid
    conn.commit()
    conn.close()

    # Dispara extração assíncrona (best-effort, não bloqueia resposta)
    try:
        from extractor import extrair_produtos_pdf
        extrair_produtos_pdf(eid)
    except Exception as e:
        # A extração falhou, mas o PDF já está no ar
        conn = get_db()
        conn.execute(
            "UPDATE encartes SET status_extracao='erro', extracao_log=? WHERE id=?",
            (f"Falha na extração: {e}", eid),
        )
        conn.commit()
        conn.close()

    return jsonify({"ok": True, "encarte_id": eid, "pdf_path": nome_seguro}), 201


@app.route("/api/mercado/encarte/<int:eid>/reextrair", methods=["POST"])
def mercado_reextrair(eid):
    if not requer_mercado_logado():
        return jsonify({"erro": "Não autenticado"}), 401
    mid = session["mercado_id"]
    conn = get_db()
    e = conn.execute("SELECT * FROM encartes WHERE id=? AND mercado_id=?", (eid, mid)).fetchone()
    if not e:
        conn.close()
        return jsonify({"erro": "Encarte não encontrado"}), 404
    conn.execute("UPDATE encartes SET status_extracao='pendente' WHERE id=?", (eid,))
    conn.commit()
    conn.close()
    try:
        from extractor import extrair_produtos_pdf
        extrair_produtos_pdf(eid)
    except Exception as e:
        return jsonify({"erro": str(e)}), 500
    return jsonify({"ok": True})


@app.route("/api/mercado/encarte/<int:eid>/produtos", methods=["GET", "POST", "DELETE"])
def mercado_produtos_encarte(eid):
    if not requer_mercado_logado():
        return jsonify({"erro": "Não autenticado"}), 401
    mid = session["mercado_id"]
    conn = get_db()
    e = conn.execute("SELECT * FROM encartes WHERE id=? AND mercado_id=?", (eid, mid)).fetchone()
    if not e:
        conn.close()
        return jsonify({"erro": "Encarte não encontrado"}), 404

    if request.method == "GET":
        rows = conn.execute("SELECT * FROM produtos WHERE encarte_id=? ORDER BY nome", (eid,)).fetchall()
        conn.close()
        return jsonify(rows_to_dict(rows))

    if request.method == "DELETE":
        pid = request.args.get("pid")
        conn.execute("DELETE FROM produtos WHERE id=? AND encarte_id=?", (pid, eid))
        conn.commit()
        conn.close()
        return jsonify({"ok": True})

    # POST — adicionar/editar produto manualmente
    d = request.json or {}
    if not d.get("nome") or not d.get("preco"):
        return jsonify({"erro": "nome e preco são obrigatórios"}), 400
    norm = normalizar_produto(d["nome"], d.get("marca", ""), d.get("unidade", ""))
    if d.get("id"):
        conn.execute(
            "UPDATE produtos SET nome=?, marca=?, preco=?, unidade=?, normalizado=? WHERE id=? AND encarte_id=?",
            (d["nome"], d.get("marca"), d["preco"], d.get("unidade"), norm, d["id"], eid),
        )
    else:
        conn.execute(
            """INSERT INTO produtos (encarte_id, mercado_id, nome, marca, preco, unidade, normalizado)
               VALUES (?,?,?,?,?,?,?)""",
            (eid, mid, d["nome"], d.get("marca"), d["preco"], d.get("unidade"), norm),
        )
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Painel ADMIN MASTER (você)
# ---------------------------------------------------------------------------
@app.route("/api/admin/mercados")
def admin_lista_mercados():
    if not requer_admin_master():
        return jsonify({"erro": "Admin master necessário"}), 401
    conn = get_db()
    rows = conn.execute(
        """SELECT m.*,
                  (SELECT COUNT(*) FROM encartes e WHERE e.mercado_id = m.id) as total_encartes,
                  (SELECT COUNT(*) FROM produtos p WHERE p.mercado_id = m.id) as total_produtos
           FROM mercados m
           ORDER BY m.criado_em DESC"""
    ).fetchall()
    conn.close()
    return jsonify(rows_to_dict(rows))


@app.route("/api/admin/mercado", methods=["POST"])
def admin_cria_mercado():
    if not requer_admin_master():
        return jsonify({"erro": "Admin master necessário"}), 401
    d = request.json or {}
    if not d.get("nome") or not d.get("email_login"):
        return jsonify({"erro": "nome e email_login são obrigatórios"}), 400

    senha = d.get("senha") or "mercado123"  # senha padrão, deve ser trocada
    senha_hash = generate_password_hash(senha)
    piloto_inicio = d.get("piloto_inicio") or hoje()
    piloto_fim = d.get("piloto_fim") or data_futura(PILOTO_DIAS)

    conn = get_db()
    try:
        cur = conn.execute(
            """INSERT INTO mercados
               (nome, cidade, estado, endereco, telefone, latitude, longitude,
                email_login, senha_hash, piloto_inicio, piloto_fim, mensalidade, status)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?, 'piloto')""",
            (
                d["nome"], d.get("cidade"), d.get("estado"), d.get("endereco"),
                d.get("telefone"), d.get("latitude"), d.get("longitude"),
                d["email_login"].lower(), senha_hash, piloto_inicio, piloto_fim,
                d.get("mensalidade", MENSALIDADE_BASE),
            ),
        )
        mid = cur.lastrowid
        conn.commit()
        conn.close()
        return jsonify({"ok": True, "id": mid, "senha_inicial": senha, "piloto_fim": piloto_fim}), 201
    except sqlite3.IntegrityError as e:
        conn.close()
        return jsonify({"erro": f"Email já cadastrado: {e}"}), 400


@app.route("/api/admin/mercado/<int:mid>", methods=["DELETE"])
def admin_remove_mercado(mid):
    if not requer_admin_master():
        return jsonify({"erro": "Admin master necessário"}), 401
    conn = get_db()
    conn.execute("DELETE FROM mercados WHERE id=?", (mid,))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


@app.route("/api/admin/destaque/<int:mid>", methods=["POST"])
def admin_destaque(mid):
    """Ativa/desativa destaque patrocinado (R$2000/mês). Máx 20 simultâneos."""
    if not requer_admin_master():
        return jsonify({"erro": "Admin master necessário"}), 401
    d = request.json or {}
    ativar = bool(d.get("destaque"))
    conn = get_db()

    if ativar:
        # Verifica limite
        atual = conn.execute(
            """SELECT COUNT(*) as c FROM mercados
               WHERE destaque=1 AND date(destaque_fim) >= date('now')"""
        ).fetchone()
        if atual["c"] >= MAX_DESTAQUES:
            conn.close()
            return jsonify({"erro": f"Limite de {MAX_DESTAQUES} destaques atingido"}), 400
        inicio = d.get("inicio") or hoje()
        fim = d.get("fim") or data_futura(30)
        conn.execute(
            "UPDATE mercados SET destaque=1, destaque_inicio=?, destaque_fim=? WHERE id=?",
            (inicio, fim, mid),
        )
    else:
        conn.execute(
            "UPDATE mercados SET destaque=0, destaque_fim=? WHERE id=?",
            (hoje(), mid),
        )
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


@app.route("/api/admin/status/<int:mid>", methods=["POST"])
def admin_status(mid):
    """Altera status do mercado (piloto → ativo → inativo)."""
    if not requer_admin_master():
        return jsonify({"erro": "Admin master necessário"}), 401
    d = request.json or {}
    novo = d.get("status")
    if novo not in ("piloto", "ativo", "inativo"):
        return jsonify({"erro": "status inválido"}), 400
    conn = get_db()
    conn.execute("UPDATE mercados SET status=? WHERE id=?", (novo, mid))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


@app.route("/api/admin/seed", methods=["POST"])
def admin_seed():
    if not requer_admin_master():
        return jsonify({"erro": "Admin master necessário"}), 401
    try:
        import seed
        seed.run_seed(force=True)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"erro": str(e)}), 500


# ---------------------------------------------------------------------------
# Inicialização
# ---------------------------------------------------------------------------
def main():
    init_db()
    # Seed automático na primeira execução
    try:
        import seed
        seed.run_seed(force=False)
    except Exception as e:
        print("Aviso: seed automático falhou:", e)
    print("\n" + "=" * 60)
    print("  Ofertas do Litoral — App B2B v2")
    print(f"  Servidor: http://{APP_HOST}:{APP_PORT}")
    print("=" * 60)
    print("  Admin master: admin@ofertasdo.litoral / admin123")
    print("  Mercado demo: domlevi@exemplo.com / mercado123")
    print("  Mercado demo: quintetto@exemplo.com / mercado123")
    print("=" * 60)
    print(f"  Piloto: {PILOTO_DIAS} dias grátis | Mensalidade: R$ {MENSALIDADE_BASE:.2f}")
    print(f"  Destaque home: R$ {DESTAQUE_MENSAL:.2f}/mês (máx {MAX_DESTAQUES})")
    print("=" * 60 + "\n")
    app.run(host=APP_HOST, port=APP_PORT, debug=False)


if __name__ == "__main__":
    main()
