"""
Extractor — converte PDF de encarte em lista de produtos usando IA.

Estratégia:
  1. Converte cada página do PDF em imagem PNG (usando PyMuPDF / fitz).
  2. Chama o CLI `z-ai vision` com prompt específico para extrair produtos.
  3. Parse do JSON retornado.
  4. Insere produtos no banco, marcando o encarte como 'concluido'.

Dependências:
  - PyMuPDF (pip install pymupdf) para renderizar PDF → imagem
  - z-ai CLI (npm install -g z-ai-web-dev-sdk) para visão IA
    OU defina ZAI_CLI="" para desativar extração automática
    e fazer cadastro manual.

Em produção, substitua a chamada de subprocesso por uma chamada direta à
API do seu provedor de IA (OpenAI Vision, Google Gemini, ZAI, etc.).
"""

import os
import sys
import json
import sqlite3
import shutil
import subprocess
import tempfile
from pathlib import Path

# Importa configurações do app
sys.path.insert(0, str(Path(__file__).resolve().parent))
from app import DB_PATH, PDF_DIR, ZAI_CLI, normalizar_produto  # noqa: E402

PROMPT_EXTRACAO = """Este é o encarte de um supermercado brasileiro.
Analise cuidadosamente e retorne APENAS um JSON válido (sem markdown, sem texto adicional) com esta estrutura:

{
  "nome_mercado": "",
  "cidade": "",
  "estado": "",
  "endereco": "",
  "telefone": "",
  "data_inicio": "DD/MM/AAAA se visível",
  "data_fim": "DD/MM/AAAA se visível",
  "produtos": [
    {"nome": "", "marca": "", "preco": "0,00", "unidade": "kg/g/ml/L/un"}
  ]
}

Regras:
- Liste TODOS os produtos visíveis no encarte.
- Em "preco" use vírgula como separador decimal (ex: "4,99").
- Em "unidade" informe kg, g, ml, L, un, ou valor com unidade (ex: "500g", "2L", "12un").
- Em "marca" informe a marca do produto, se houver. Se não houver marca clara, deixe vazio.
- Em "nome" coloque apenas o nome do produto sem a marca (ex: "Arroz Parboilizado", não "Arroz Urbano").
- Não invente dados. Se um campo não estiver visível, deixe vazio.
- Retorne SOMENTE o JSON. Sem explicações, sem markdown, sem crases."""


def pdf_para_imagens(pdf_path: Path, out_dir: Path, dpi: int = 150):
    """Converte PDF em PNGs (uma por página). Requer PyMuPDF."""
    import fitz  # PyMuPDF
    imagens = []
    doc = fitz.open(str(pdf_path))
    for i, page in enumerate(doc):
        pix = page.get_pixmap(dpi=dpi)
        out = out_dir / f"pagina_{i+1:03d}.png"
        pix.save(str(out))
        imagens.append(out)
    doc.close()
    return imagens


def chamar_vision_zai(imagem_path: Path) -> dict:
    """Chama o CLI z-ai vision e retorna o JSON parseado."""
    if not ZAI_CLI:
        raise RuntimeError(
            "ZAI_CLI não configurado. Defina ZAI_CLI no .env ou instale "
            "z-ai-web-dev-sdk (npm install -g z-ai-web-dev-sdk)."
        )
    with tempfile.NamedTemporaryFile(mode="w+", suffix=".json", delete=False) as tmp:
        out_path = tmp.name
    try:
        cmd = [
            ZAI_CLI, "vision",
            "-p", PROMPT_EXTRACAO,
            "-i", str(imagem_path),
            "-o", out_path,
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode != 0:
            raise RuntimeError(f"z-ai vision falhou: {result.stderr[:500]}")
        with open(out_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Resposta vem dentro de choices[0].message.content (formato OpenAI)
        content = data["choices"][0]["message"]["content"]
        # Limpa markdown se houver
        content = content.strip()
        if content.startswith("```"):
            content = content.split("```")[1]
            if content.startswith("json"):
                content = content[4:]
        content = content.strip()
        return json.loads(content)
    finally:
        try:
            os.unlink(out_path)
        except OSError:
            pass


def extrair_produtos_pdf(encarte_id: int) -> dict:
    """Função principal: recebe ID do encarte, extrai produtos e salva no banco."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    encarte = conn.execute("SELECT * FROM encartes WHERE id=?", (encarte_id,)).fetchone()
    if not encarte:
        conn.close()
        raise RuntimeError(f"Encarte {encarte_id} não encontrado")

    pdf_path = PDF_DIR / encarte["pdf_path"]
    if not pdf_path.exists():
        conn.execute(
            "UPDATE encartes SET status_extracao='erro', extracao_log=? WHERE id=?",
            (f"PDF não encontrado: {pdf_path}", encarte_id),
        )
        conn.commit()
        conn.close()
        raise RuntimeError(f"PDF não encontrado: {pdf_path}")

    conn.execute(
        "UPDATE encartes SET status_extracao='processando', extracao_log=NULL WHERE id=?",
        (encarte_id,),
    )
    conn.commit()

    try:
        # 1. PDF → imagens
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            imagens = pdf_para_imagens(pdf_path, tmp)

            todos_produtos = []
            metadados = {}
            for img in imagens:
                dados = chamar_vision_zai(img)
                if isinstance(dados, dict):
                    if "produtos" in dados:
                        todos_produtos.extend(dados["produtos"])
                    if not metadados.get("nome_mercado") and dados.get("nome_mercado"):
                        metadados = dados

            # 2. Insere produtos no banco
            mid = encarte["mercado_id"]
            # Limpa produtos antigos deste encarte
            conn.execute("DELETE FROM produtos WHERE encarte_id=?", (encarte_id,))
            for p in todos_produtos:
                nome = (p.get("nome") or "").strip()
                preco = (p.get("preco") or "").strip()
                if not nome or not preco:
                    continue
                marca = (p.get("marca") or "").strip()
                unidade = (p.get("unidade") or "").strip()
                norm = normalizar_produto(nome, marca, unidade)
                conn.execute(
                    """INSERT INTO produtos (encarte_id, mercado_id, nome, marca, preco, unidade, normalizado)
                       VALUES (?,?,?,?,?,?,?)""",
                    (encarte_id, mid, nome, marca, preco, unidade, norm),
                )

            conn.execute(
                "UPDATE encartes SET status_extracao='concluido', extracao_log=? WHERE id=?",
                (json.dumps({
                    "total_paginas": len(imagens),
                    "total_produtos": len(todos_produtos),
                    "metadados": metadados,
                }, ensure_ascii=False), encarte_id),
            )
            conn.commit()
            conn.close()
            return {"ok": True, "total_produtos": len(todos_produtos)}

    except Exception as e:
        conn.execute(
            "UPDATE encartes SET status_extracao='erro', extracao_log=? WHERE id=?",
            (str(e)[:1000], encarte_id),
        )
        conn.commit()
        conn.close()
        raise


if __name__ == "__main__":
    # Modo standalone: python extractor.py <encarte_id>
    if len(sys.argv) < 2:
        print("Uso: python extractor.py <encarte_id>")
        sys.exit(1)
    eid = int(sys.argv[1])
    resultado = extrair_produtos_pdf(eid)
    print(json.dumps(resultado, indent=2, ensure_ascii=False))
