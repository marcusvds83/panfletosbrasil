@echo off
REM ============================================================
REM  Ofertas do Litoral - Iniciador Windows (v2 B2B)
REM  Duplo clique para rodar. Abre http://127.0.0.1:5000
REM ============================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo  ============================================================
echo   Ofertas do Litoral - App B2B v2
echo  ============================================================
echo.

REM ---- 1) Procurar Python instalado ----
set "PYCMD="
where python >nul 2>&1 && set "PYCMD=python"
if not defined PYCMD where py >nul 2>&1 && set "PYCMD=py -3"
if not defined PYCMD where python3 >nul 2>&1 && set "PYCMD=python3"

if not defined PYCMD (
  echo  [ERRO] Python 3 nao encontrado.
  echo.
  echo  Instale em: https://www.python.org/downloads/windows/
  echo  Marque a opcao "Add Python to PATH" durante a instalacao.
  echo.
  pause
  exit /b 1
)

echo  Python encontrado: %PYCMD%

REM ---- 2) Criar ambiente virtual (.venv) se nao existir ----
if not exist ".venv\Scripts\python.exe" (
  echo  Criando ambiente virtual .venv ...
  %PYCMD% -m venv .venv
  if errorlevel 1 (
    echo  [ERRO] Falha ao criar .venv.
    pause
    exit /b 1
  )
)

REM ---- 3) Ativar .venv ----
call ".venv\Scripts\activate.bat"

REM ---- 4) Instalar dependencias (somente se necessario) ----
python -c "import flask, fitz" 2>nul
if errorlevel 1 (
  echo  Instalando dependencias ^(Flask + PyMuPDF^) ...
  pip install --upgrade pip
  pip install -r requirements.txt
  if errorlevel 1 (
    echo  [ERRO] Falha ao instalar dependencias.
    pause
    exit /b 1
  )
)

REM ---- 5) Criar .env a partir do .env.example, se nao existir ----
if not exist ".env" (
  if exist ".env.example" copy ".env.example" ".env" >nul
  echo  Arquivo .env criado a partir do .env.example
)

REM ---- 6) Verificar CLI z-ai (opcional, para extracao automatica) ----
where z-ai >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [AVISO] CLI z-ai nao encontrado. Extracao automatica desativada.
  echo          Para ativar: instale Node.js e execute:
  echo            npm install -g z-ai-web-dev-sdk
  echo          Ou deixe vazio no .env e cadastre produtos manualmente.
  echo.
)

REM ---- 7) Abrir navegador e iniciar servidor ----
echo.
echo  Abrindo http://127.0.0.1:5000 no navegador...
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:5000

echo.
echo  Servidor rodando. Pressione CTRL+C para parar.
echo.
python app.py

pause
