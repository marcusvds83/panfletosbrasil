/* Ofertas do Litoral — front-end v2 */

const estado = {
  mercados: [],
  cidades: new Set(),
  usuario: null,
  mercadoLogado: null,
};

// ---------------------------------------------------------------------------
// Navegação
// ---------------------------------------------------------------------------
document.querySelectorAll('.btn-tab').forEach(btn => {
  btn.addEventListener('click', () => navegar(btn.dataset.view));
});

function navegar(view) {
  document.querySelectorAll('.btn-tab').forEach(b => b.classList.remove('active'));
  const btn = document.querySelector(`[data-view="${view}"]`);
  if (btn) btn.classList.add('active');
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  const el = document.getElementById('view-' + view);
  if (el) el.classList.add('active');
  if (view === 'comparar') carregarComparativo();
  if (view === 'painel-mercado') verificarSessaoMercado();
  if (view === 'painel-admin') verificarSessaoAdmin();
  if (view === 'mercados') carregarMercados();
}

function voltarParaMercados() { navegar('mercados'); }

// ---------------------------------------------------------------------------
// Filtros
// ---------------------------------------------------------------------------
document.getElementById('busca-mercado').addEventListener('input', aplicarFiltros);
document.getElementById('filtro-cidade').addEventListener('change', aplicarFiltros);

function aplicarFiltros() {
  const termo = document.getElementById('busca-mercado').value.toLowerCase().trim();
  const cidade = document.getElementById('filtro-cidade').value;
  const filtrados = estado.mercados.filter(m => {
    const matchTermo = !termo ||
      m.nome.toLowerCase().includes(termo) ||
      (m.cidade || '').toLowerCase().includes(termo);
    const matchCidade = !cidade || m.cidade === cidade;
    return matchTermo && matchCidade;
  });
  renderMercados(filtrados);
}

// ---------------------------------------------------------------------------
// Mercados (home pública)
// ---------------------------------------------------------------------------
async function carregarMercados() {
  try {
    const r = await fetch('/api/mercados');
    const data = await r.json();
    estado.mercados = [...(data.destaques || []), ...(data.mercados || [])];
    estado.cidades = new Set(estado.mercados.map(m => m.cidade).filter(Boolean));
    const sel = document.getElementById('filtro-cidade');
    sel.innerHTML = '<option value="">Todas as cidades</option>' +
      [...estado.cidades].sort().map(c => `<option>${c}</option>`).join('');
    renderDestaques(data.destaques || []);
    renderMercados(data.mercados || []);
  } catch (e) {
    document.getElementById('lista-mercados').innerHTML =
      '<div class="empty">Erro ao carregar mercados.</div>';
  }
}

function renderDestaques(destaques) {
  const cont = document.getElementById('destaques-home');
  if (!destaques || !destaques.length) { cont.innerHTML = ''; return; }
  cont.innerHTML = `
    <p class="titulo-destaques">Mercados em destaque (patrocinados)</p>
    ${destaques.map(m => `
      <div class="icone-destaque" onclick="abrirMercado(${m.id})" title="${esc(m.nome)}">
        <span class="tag-patrocinado">Patrocinado</span>
        <div class="logo-circle">${iniciais(m.nome)}</div>
        <span>${esc(m.nome.length > 14 ? m.nome.slice(0, 13) + '…' : m.nome)}</span>
      </div>
    `).join('')}
  `;
}

function renderMercados(lista) {
  const cont = document.getElementById('lista-mercados');
  if (!lista.length) {
    cont.innerHTML = '<div class="empty">Nenhum mercado encontrado.</div>';
    return;
  }
  cont.innerHTML = lista.map(m => `
    <div class="card-mercado" onclick="abrirMercado(${m.id})">
      ${m.destaque ? '<span class="badge-patrocinado">Patrocinado</span>' : ''}
      <h3>${esc(m.nome)}</h3>
      <p class="cidade">${esc(m.cidade || '')}${m.estado ? ' — ' + esc(m.estado) : ''}</p>
      ${m.endereco ? `<div class="info-row"><strong>Endereço:</strong> ${esc(m.endereco)}</div>` : ''}
      ${m.telefone ? `<div class="info-row"><strong>Telefone:</strong> ${esc(m.telefone)}</div>` : ''}
      <div class="preview-pdf">Ver encarte em PDF</div>
    </div>
  `).join('');
}

// ---------------------------------------------------------------------------
// Detalhe
// ---------------------------------------------------------------------------
async function abrirMercado(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById('view-detalhe').classList.add('active');
  const cont = document.getElementById('detalhe-conteudo');
  cont.innerHTML = '<div class="loading">Carregando...</div>';
  try {
    const r = await fetch(`/api/mercado/${id}`);
    const data = await r.json();
    const m = data.mercado;
    const produtos = data.produtos || [];
    const encartes = data.encartes || [];
    cont.innerHTML = `
      <h2>${esc(m.nome)} ${m.destaque ? '<span class="tag-status" style="background:linear-gradient(135deg,#ff7a00,#ff5a00);color:#fff;">Patrocinado</span>' : ''}</h2>
      <p class="cidade">${esc(m.cidade || '')}${m.estado ? ' — ' + esc(m.estado) : ''}</p>
      ${m.endereco ? `<div class="info-row"><strong>Endereço:</strong> ${esc(m.endereco)}</div>` : ''}
      ${m.telefone ? `<div class="info-row"><strong>Telefone:</strong> ${esc(m.telefone)}</div>` : ''}
      <div class="detalhe-grid">
        <div class="detalhe-section">
          <h3>Produtos do encarte (${produtos.length})</h3>
          <ul class="lista-produtos">
            ${produtos.map(p => `
              <li class="item-produto">
                <div><span class="nome">${esc(p.nome)}</span>${p.marca ? `<span class="marca">${esc(p.marca)}</span>` : ''}</div>
                <div><span class="preco">R$ ${esc(p.preco)}</span>${p.unidade ? `<span class="unidade">/${esc(p.unidade)}</span>` : ''}</div>
              </li>
            `).join('') || '<li class="muted">Nenhum produto cadastrado.</li>'}
          </ul>
        </div>
        <div class="detalhe-section">
          <h3>Encartes (${encartes.length})</h3>
          ${encartes.map(e => `
            <div class="encarte-card">
              <p class="titulo">${esc(e.titulo || 'Encarte')}</p>
              <p class="validade">${e.data_inicio ? 'Válido de ' + esc(e.data_inicio) : ''} ${e.data_fim ? ' até ' + esc(e.data_fim) : ''}</p>
              <div class="encarte-thumb" onclick="abrirPdf('/static/pdfs/${encodeURIComponent(e.pdf_path)}')">📄 Abrir encarte em PDF</div>
            </div>
          `).join('') || '<p class="muted">Nenhum encarte cadastrado.</p>'}
        </div>
      </div>
    `;
  } catch (e) {
    cont.innerHTML = '<div class="empty">Erro ao carregar mercado.</div>';
  }
}

// ---------------------------------------------------------------------------
// Comparar
// ---------------------------------------------------------------------------
async function carregarComparativo() {
  const cont = document.getElementById('lista-comparacao');
  cont.innerHTML = '<div class="loading">Carregando comparativo...</div>';
  try {
    const r = await fetch('/api/comparar');
    const data = await r.json();
    if (!data.length) {
      cont.innerHTML = '<div class="empty">Ainda não há produtos equivalentes em 2+ mercados.</div>';
      return;
    }
    cont.innerHTML = data.map(g => `
      <div class="card-comparacao">
        <div class="titulo-comp">
          <span>${esc(g.produto)} ${g.marca ? '<span class="marca" style="color:#6b7785;font-weight:500;">— ' + esc(g.marca) + '</span>' : ''}</span>
          ${g.unidade ? `<span class="unidade">/${esc(g.unidade)}</span>` : ''}
        </div>
        <div class="lista-opcoes">
          ${g.opcoes.map((o, i) => `
            <div class="opcao ${i === 0 ? 'menor-preco' : ''}">
              <div class="mercado-info">${i === 0 ? '<span class="tag-menor">Menor</span>' : ''}${esc(o.mercado_nome)} <span style="color:#6b7785;font-size:11px;">${esc(o.mercado_cidade || '')}</span></div>
              <div class="preco-info">R$ ${esc(o.preco)}</div>
            </div>
          `).join('')}
        </div>
      </div>
    `).join('');
  } catch (e) {
    cont.innerHTML = '<div class="empty">Erro ao carregar comparativo.</div>';
  }
}

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------
async function verificarSessao() {
  const r = await fetch('/api/auth/eu');
  estado.usuario = await r.json();
  const ui = document.getElementById('user-info');
  if (estado.usuario && estado.usuario.tipo) {
    ui.innerHTML = `👤 ${esc(estado.usuario.email)} <button class="btn-sec" onclick="logout()" style="padding:4px 10px;font-size:11px;">Sair</button>`;
  } else {
    ui.innerHTML = '';
  }
  return estado.usuario;
}

async function logout() {
  await fetch('/api/auth/logout', { method: 'POST' });
  estado.usuario = null;
  estado.mercadoLogado = null;
  verificarSessao();
  navegar('mercados');
}

document.getElementById('form-login-mercado').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const fd = new FormData(ev.target);
  const r = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: fd.get('email'), senha: fd.get('senha') }),
  });
  const data = await r.json();
  if (!r.ok) { alert('Erro: ' + (data.erro || 'login falhou')); return; }
  await verificarSessao();
  verificarSessaoMercado();
});

document.getElementById('form-login-admin').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const fd = new FormData(ev.target);
  const r = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: fd.get('email'), senha: fd.get('senha') }),
  });
  const data = await r.json();
  if (!r.ok) { alert('Erro: ' + (data.erro || 'login falhou')); return; }
  await verificarSessao();
  verificarSessaoAdmin();
});

// ---------------------------------------------------------------------------
// Painel do Mercado
// ---------------------------------------------------------------------------
async function verificarSessaoMercado() {
  const u = await verificarSessao();
  if (u && u.tipo === 'mercado') {
    document.getElementById('login-mercado-box').style.display = 'none';
    document.getElementById('painel-mercado-logado').style.display = 'block';
    carregarPainelMercado();
  } else if (u && u.tipo === 'admin_master') {
    document.getElementById('login-mercado-box').style.display = 'none';
    document.getElementById('painel-mercado-logado').style.display = 'block';
    carregarPainelMercado(u.mercado_id);
  } else {
    document.getElementById('login-mercado-box').style.display = 'block';
    document.getElementById('painel-mercado-logado').style.display = 'none';
  }
}

async function carregarPainelMercado() {
  try {
    const r = await fetch('/api/mercado/conta');
    if (!r.ok) {
      const e = await r.json();
      alert('Erro: ' + (e.erro || 'não autenticado'));
      logout();
      return;
    }
    const data = await r.json();
    estado.mercadoLogado = data;
    const m = data.mercado;
    document.getElementById('pm-nome').textContent = m.nome;
    const statusClass = data.status_efetivo === 'piloto' ? '' :
                        data.status_efetivo === 'ativo' ? 'green' :
                        data.status_efetivo === 'piloto_expirado' ? 'warn' : 'red';
    document.getElementById('pm-status').innerHTML =
      `<span class="tag-status ${data.status_efetivo}">${data.status_efetivo.replace('_', ' ')}</span>` +
      ` &nbsp; Piloto até ${m.piloto_fim || '—'} &nbsp;•&nbsp; Mensalidade: R$ ${m.mensalidade || 0}`;

    // Stats
    document.getElementById('pm-stats').innerHTML = `
      <div class="stat-card"><div class="label">Encartes</div><div class="value">${data.encartes.length}</div></div>
      <div class="stat-card green"><div class="label">Produtos</div><div class="value">${data.total_produtos}</div></div>
      <div class="stat-card ${m.destaque ? 'green' : ''}"><div class="label">Destaque home</div><div class="value">${m.destaque ? 'Ativo' : '—'}</div></div>
    `;

    // Encartes
    const cont = document.getElementById('pm-encartes');
    if (!data.encartes.length) {
      cont.innerHTML = '<div class="empty">Nenhum encarte enviado ainda. Use o formulário acima.</div>';
    } else {
      cont.innerHTML = data.encartes.map(e => `
        <div class="card-encarte-pm">
          <div class="header-encarte">
            <div>
              <p class="titulo">${esc(e.titulo || 'Encarte')}</p>
              <p class="validade">${e.data_inicio ? 'De ' + esc(e.data_inicio) : ''} ${e.data_fim ? 'até ' + esc(e.data_fim) : ''}</p>
            </div>
            <span class="status-extracao ${e.status_extracao}">${e.status_extracao}</span>
          </div>
          <div class="acoes">
            <button class="btn-icon" onclick="abrirPdf('/static/pdfs/${encodeURIComponent(e.pdf_path)}')">📄 Ver PDF</button>
            <button class="btn-icon success" onclick="carregarProdutosEncarte(${e.id})">👁 Ver produtos</button>
            <button class="btn-icon warn" onclick="reextrair(${e.id})">🔄 Re-extrair com IA</button>
          </div>
          <div class="produtos-lista" id="produtos-encarte-${e.id}" style="display:none"></div>
        </div>
      `).join('');
    }
  } catch (e) {
    alert('Erro ao carregar painel: ' + e);
  }
}

async function carregarProdutosEncarte(eid) {
  const cont = document.getElementById('produtos-encarte-' + eid);
  if (cont.style.display === 'block') { cont.style.display = 'none'; return; }
  cont.style.display = 'block';
  cont.innerHTML = '<div class="loading">Carregando...</div>';
  const r = await fetch(`/api/mercado/encarte/${eid}/produtos`);
  const data = await r.json();
  if (!data.length) {
    cont.innerHTML = '<p class="muted">Nenhum produto extraído. Clique em "Re-extrair com IA" ou adicione manualmente.</p>' +
      '<form onsubmit="adicionarProduto(event, ' + eid + ')" style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;">' +
      '<input name="nome" placeholder="Produto" style="flex:1;min-width:140px;padding:8px;border:1px solid #e4e8ef;border-radius:6px;font-size:13px;">' +
      '<input name="marca" placeholder="Marca" style="width:100px;padding:8px;border:1px solid #e4e8ef;border-radius:6px;font-size:13px;">' +
      '<input name="preco" placeholder="R$" style="width:80px;padding:8px;border:1px solid #e4e8ef;border-radius:6px;font-size:13px;">' +
      '<input name="unidade" placeholder="kg" style="width:70px;padding:8px;border:1px solid #e4e8ef;border-radius:6px;font-size:13px;">' +
      '<button class="btn-primary" style="padding:8px 14px;font-size:13px;">+ Add</button>' +
      '</form>';
    return;
  }
  cont.innerHTML = `
    <h4>Produtos extraídos (${data.length})</h4>
    <ul>
      ${data.map(p => `
        <li>
          <div><strong>${esc(p.nome)}</strong> ${p.marca ? '<span class="marca">' + esc(p.marca) + '</span>' : ''}</div>
          <div>R$ ${esc(p.preco)} ${p.unidade ? '<span class="unidade">/' + esc(p.unidade) + '</span>' : ''} <button class="btn-icon danger" onclick="removerProduto(${p.id}, ${eid})" style="margin-left:8px;padding:2px 6px;">✕</button></div>
        </li>
      `).join('')}
    </ul>
    <form onsubmit="adicionarProduto(event, ${eid})" style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px;">
      <input name="nome" placeholder="Produto" style="flex:1;min-width:140px;padding:8px;border:1px solid #e4e8ef;border-radius:6px;font-size:13px;">
      <input name="marca" placeholder="Marca" style="width:100px;padding:8px;border:1px solid #e4e8ef;border-radius:6px;font-size:13px;">
      <input name="preco" placeholder="R$" style="width:80px;padding:8px;border:1px solid #e4e8ef;border-radius:6px;font-size:13px;">
      <input name="unidade" placeholder="kg" style="width:70px;padding:8px;border:1px solid #e4e8ef;border-radius:6px;font-size:13px;">
      <button class="btn-primary" style="padding:8px 14px;font-size:13px;">+ Add</button>
    </form>
  `;
}

async function adicionarProduto(ev, eid) {
  ev.preventDefault();
  const fd = new FormData(ev.target);
  const body = {};
  fd.forEach((v, k) => { if (v) body[k] = v; });
  const r = await fetch(`/api/mercado/encarte/${eid}/produtos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (r.ok) { ev.target.reset(); carregarProdutosEncarte(eid); }
  else { alert('Erro ao adicionar'); }
}

async function removerProduto(pid, eid) {
  if (!confirm('Remover produto?')) return;
  await fetch(`/api/mercado/encarte/${eid}/produtos?pid=${pid}`, { method: 'DELETE' });
  carregarProdutosEncarte(eid);
}

async function reextrair(eid) {
  if (!confirm('Re-extrair produtos do PDF com IA? Pode levar alguns segundos.')) return;
  const r = await fetch(`/api/mercado/encarte/${eid}/reextrair`, { method: 'POST' });
  const data = await r.json();
  if (r.ok) {
    alert('Extração concluída! Recarregando...');
    carregarPainelMercado();
  } else {
    alert('Erro: ' + (data.erro || 'falha na extração') + '\n\nVerifique se o CLI z-ai está instalado e configurado no .env.');
  }
}

document.getElementById('form-upload-encarte').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const fd = new FormData(ev.target);
  const r = await fetch('/api/mercado/encarte', { method: 'POST', body: fd });
  const data = await r.json();
  if (r.ok) {
    alert('Encarte enviado! Extração iniciada (pode levar alguns segundos).');
    ev.target.reset();
    setTimeout(() => carregarPainelMercado(), 2000);
  } else {
    alert('Erro: ' + (data.erro || 'falha no upload'));
  }
});

// ---------------------------------------------------------------------------
// Painel Admin
// ---------------------------------------------------------------------------
async function verificarSessaoAdmin() {
  const u = await verificarSessao();
  if (u && u.tipo === 'admin_master') {
    document.getElementById('login-admin-box').style.display = 'none';
    document.getElementById('painel-admin-logado').style.display = 'block';
    carregarPainelAdmin();
  } else {
    document.getElementById('login-admin-box').style.display = 'block';
    document.getElementById('painel-admin-logado').style.display = 'none';
  }
}

async function carregarPainelAdmin() {
  const r = await fetch('/api/admin/mercados');
  if (!r.ok) return;
  const mercados = await r.json();
  const ativos = mercados.filter(m => m.status === 'ativo').length;
  const piloto = mercados.filter(m => m.status === 'piloto').length;
  const inativos = mercados.filter(m => m.status === 'inativo').length;
  const destaques = mercados.filter(m => m.destaque).length;
  const receitaPotencial = ativos * 800 + destaques * 2000;

  document.getElementById('admin-stats').innerHTML = `
    <div class="stat-card"><div class="label">Total mercados</div><div class="value">${mercados.length}</div></div>
    <div class="stat-card"><div class="label">Em piloto</div><div class="value">${piloto}</div><div class="sub">60 dias grátis</div></div>
    <div class="stat-card green"><div class="label">Ativos</div><div class="value">${ativos}</div><div class="sub">R$800/mês</div></div>
    <div class="stat-card warn"><div class="label">Destaques</div><div class="value">${destaques}</div><div class="sub">R$2000/mês (máx 20)</div></div>
    <div class="stat-card green"><div class="label">Receita mensal potencial</div><div class="value">R$ ${receitaPotencial.toLocaleString('pt-BR')}</div></div>
    <div class="stat-card red"><div class="label">Inativos</div><div class="value">${inativos}</div></div>
  `;

  const cont = document.getElementById('admin-lista-mercados');
  cont.innerHTML = `
    <div class="linha-admin-mercado" style="background:#eef1f6;font-weight:600;">
      <span>Mercado</span><span>Cidade</span><span>Status</span><span>Encartes</span><span>Produtos</span><span>Ações</span>
    </div>
    ${mercados.map(m => `
      <div class="linha-admin-mercado">
        <div>
          <div class="nome">${esc(m.nome)} ${m.destaque ? '<span class="tag-status" style="background:linear-gradient(135deg,#ff7a00,#ff5a00);color:#fff;">⭐</span>' : ''}</div>
          <div class="cidade">${esc(m.email_login || '')}</div>
        </div>
        <div>${esc(m.cidade || '')}/${esc(m.estado || '')}</div>
        <div><span class="tag-status ${m.status}">${m.status}</span></div>
        <div>${m.total_encartes}</div>
        <div>${m.total_produtos}</div>
        <div>
          ${m.status === 'piloto' ? `<button class="btn-icon success" onclick="alterarStatus(${m.id}, 'ativo')">Ativar</button>` : ''}
          ${m.status === 'ativo' ? `<button class="btn-icon warn" onclick="alterarStatus(${m.id}, 'piloto')">Piloto</button>` : ''}
          ${m.status !== 'inativo' ? `<button class="btn-icon danger" onclick="alterarStatus(${m.id}, 'inativo')">Desativar</button>` : `<button class="btn-icon success" onclick="alterarStatus(${m.id}, 'piloto')">Reativar</button>`}
          ${!m.destaque ? `<button class="btn-icon warn" onclick="alternarDestaque(${m.id}, true)">⭐ Destacar</button>` : `<button class="btn-icon" onclick="alternarDestaque(${m.id}, false)">Remover destaque</button>`}
          <button class="btn-icon danger" onclick="removerMercado(${m.id})">Excluir</button>
        </div>
      </div>
    `).join('') || '<div class="empty">Nenhum mercado cadastrado.</div>'}
  `;
}

document.getElementById('form-cadastra-mercado').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const fd = new FormData(ev.target);
  const body = {};
  fd.forEach((v, k) => { if (v) body[k] = v; });
  const r = await fetch('/api/admin/mercado', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await r.json();
  if (r.ok) {
    alert(`Mercado cadastrado!\n\nLogin: ${body.email_login}\nSenha inicial: ${data.senha_inicial}\nPiloto até: ${data.piloto_fim}`);
    ev.target.reset();
    carregarPainelAdmin();
  } else {
    alert('Erro: ' + (data.erro || 'falha'));
  }
});

async function alterarStatus(mid, status) {
  await fetch(`/api/admin/status/${mid}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status }),
  });
  carregarPainelAdmin();
}

async function alternarDestaque(mid, ativar) {
  const r = await fetch(`/api/admin/destaque/${mid}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ destaque: ativar }),
  });
  const data = await r.json();
  if (r.ok) carregarPainelAdmin();
  else alert('Erro: ' + (data.erro || 'falha'));
}

async function removerMercado(mid) {
  if (!confirm('Excluir mercado e todos os encartes/produtos?')) return;
  await fetch(`/api/admin/mercado/${mid}`, { method: 'DELETE' });
  carregarPainelAdmin();
}

async function recarregarSeed() {
  if (!confirm('Recarregar dados de exemplo? Isso vai apagar e recriar os 2 mercados demo.')) return;
  const r = await fetch('/api/admin/seed', { method: 'POST' });
  const data = await r.json();
  alert(r.ok ? 'Dados recarregados!' : 'Erro: ' + (data.erro || 'falha'));
  if (r.ok) carregarPainelAdmin();
}

// ---------------------------------------------------------------------------
// Modal PDF
// ---------------------------------------------------------------------------
function abrirPdf(url) {
  document.getElementById('iframe-pdf').src = url;
  document.getElementById('modal-pdf').classList.add('active');
}
function fecharModal(ev) {
  if (ev.target.id === 'modal-pdf') {
    document.getElementById('modal-pdf').classList.remove('active');
    document.getElementById('iframe-pdf').src = '';
  }
}

// ---------------------------------------------------------------------------
// Util
// ---------------------------------------------------------------------------
function esc(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function iniciais(nome) {
  if (!nome) return '?';
  const parts = nome.trim().split(/\s+/);
  return (parts[0][0] + (parts[1] ? parts[1][0] : '')).toUpperCase();
}

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------
verificarSessao().then(() => carregarMercados());
