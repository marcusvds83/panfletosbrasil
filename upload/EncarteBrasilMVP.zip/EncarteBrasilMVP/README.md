# Encarte Brasil MVP Android

MVP nativo Android para comparação de encartes promocionais.

## Produto implementado no protótipo
- Consumidor vê mercados e encartes próximos.
- Encarte em formato de lista clicável.
- Adição de itens à Minha Lista.
- Comparativo visual de cesta por mercado.
- Entrada "Sou um Mercado".
- Upload local de PDF via seletor do Android.
- Fluxo visual de digitalização do encarte.
- Plano de R$ 599/mês por mercado.
- Piloto grátis por 60 dias.
- BI do mercado com impressões, cliques, adições à lista, taxa de interesse, ranking de produtos e regiões.

## Limites conscientes deste MVP
A digitalização OCR está simulada no protótipo. Para produção serão necessários:
1. Backend autenticado e multi-tenant.
2. Armazenamento de PDFs e imagens.
3. Pipeline OCR/visão para extrair produto, marca, unidade e preço.
4. Motor de normalização para comparar o mesmo SKU entre redes.
5. Geolocalização com consentimento e agregação regional compatível com LGPD.
6. Telemetria/eventos de clique e adição à lista.
7. Painel web ou APIs reais para BI.

## Compatibilidade
- minSdk 29: Android 10+
- targetSdk 35
- compileSdk 35

## Gerar APK no Android Studio
1. Abra a pasta `EncarteBrasilMVP`.
2. Aguarde o Gradle sincronizar.
3. Menu `Build` > `Generate App Bundles or APKs` > `Generate APKs`.
4. O APK debug será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Estrutura visual
O protótipo usa uma View Android customizada e APIs nativas, sem bibliotecas de UI externas. Isso reduz dependências do MVP e mantém o projeto simples para validação inicial.
