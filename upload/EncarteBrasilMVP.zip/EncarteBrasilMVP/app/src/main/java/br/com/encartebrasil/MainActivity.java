package br.com.encartebrasil;

import android.app.Activity;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.widget.Toast;
import java.util.*;

public class MainActivity extends Activity {
    AppView appView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        appView = new AppView(this);
        setContentView(appView);
    }

    public void pickPdf() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/pdf");
        startActivityForResult(i, 90);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 90 && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            appView.pdfName = uri == null ? "encarte.pdf" : uri.getLastPathSegment();
            appView.pdfSelected = true;
            appView.invalidate();
            Toast.makeText(this, "PDF selecionado para digitalização", Toast.LENGTH_SHORT).show();
        }
    }
}

class AppView extends View {
    final MainActivity activity;
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    final RectF r = new RectF();
    int screen = 0; // 0 home, 1 encarte, 2 lista, 3 comparar, 4 mercado, 5 bi
    boolean marketMode = false;
    boolean pdfSelected = false;
    String pdfName = "encarte_julho.pdf";
    final ArrayList<Product> list = new ArrayList<>();
    final ArrayList<Hit> hits = new ArrayList<>();
    final ArrayList<Product> products = new ArrayList<>();

    int green = Color.rgb(18,59,44), accent = Color.rgb(25,179,107), bg = Color.rgb(245,247,244);
    int dark = Color.rgb(24,32,29), gray = Color.rgb(104,115,109), line = Color.rgb(224,229,225);

    AppView(MainActivity a) {
        super(a); activity = a; setBackgroundColor(bg); setFocusable(true);
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(1)); stroke.setColor(line);
        products.add(new Product("Arroz Tio João 5kg", "R$ 24,90", "Mercado Aurora", "1,2 km", "ARROZ", 2490));
        products.add(new Product("Leite Integral 1L", "R$ 4,49", "SuperMais", "2,8 km", "LEITE", 449));
        products.add(new Product("Café Pilão 500g", "R$ 17,99", "Rede Econômica", "3,1 km", "CAFÉ", 1799));
        products.add(new Product("Coca-Cola 2L", "R$ 7,99", "Mercado Aurora", "1,2 km", "REFRI", 799));
        products.add(new Product("Feijão Carioca 1kg", "R$ 6,89", "SuperMais", "2,8 km", "FEIJÃO", 689));
    }

    float dp(float v){ return v*getResources().getDisplayMetrics().density; }
    void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold){
        p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(dp(size)); p.setTypeface(bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT); c.drawText(s,x,y,p);
    }
    void box(Canvas c,float l,float t,float rr,float b,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,rr,b,dp(rad),dp(rad),p);}
    void line(Canvas c,float x1,float y1,float x2,float y2,int color,float w){p.setColor(color);p.setStrokeWidth(dp(w));c.drawLine(x1,y1,x2,y2,p);}
    void pill(Canvas c,String s,float x,float y,float w,int color,int tc){box(c,x,y,x+w,y+dp(28),14,color);txt(c,s,x+dp(12),y+dp(19),11,tc,true);}
    void circleIcon(Canvas c,float cx,float cy,int color,String s){p.setColor(color);c.drawCircle(cx,cy,dp(22),p);txt(c,s,cx-dp(9),cy+dp(6),16,Color.WHITE,true);}

    @Override protected void onDraw(Canvas c){super.onDraw(c); drawTop(c); if(marketMode){ if(screen==5) drawBI(c); else drawMarket(c);} else { if(screen==0) drawHome(c); if(screen==1) drawCatalog(c); if(screen==2) drawList(c); if(screen==3) drawCompare(c);} drawBottom(c);}

    void drawTop(Canvas c){
        box(c,0,0,getWidth(),dp(86),0,green);
        if(marketMode){ txt(c,"ENCARTE",dp(20),dp(37),22,Color.WHITE,true); txt(c,"PAINEL DO MERCADO",dp(20),dp(60),10,Color.rgb(186,220,205),true); pill(c,"PILOTO • 60 DIAS",getWidth()-dp(148),dp(28),dp(130),Color.rgb(33,92,67),Color.WHITE); }
        else { txt(c,"ENCARTE",dp(20),dp(37),22,Color.WHITE,true); txt(c,"BRASIL",dp(20),dp(61),22,Color.rgb(122,233,173),true); circleIcon(c,getWidth()-dp(40),dp(43),Color.rgb(33,92,67),"SP"); }
    }

    void drawBottom(Canvas c){
        float y=getHeight()-dp(68); box(c,0,y,getWidth(),getHeight(),0,Color.WHITE); line(c,0,y,getWidth(),y,line,1);
        if(marketMode){ nav(c,"UPLOAD",0,y,screen==4); nav(c,"BI",1,y,screen==5); nav(c,"SAIR",2,y,false); }
        else { nav(c,"INÍCIO",0,y,screen==0); nav(c,"ENCARTES",1,y,screen==1); nav(c,"MINHA LISTA",2,y,screen==2); nav(c,"COMPARAR",3,y,screen==3); }
    }
    void nav(Canvas c,String s,int idx,float y,boolean active){int count=marketMode?3:4;float w=getWidth()/count;float x=idx*w;txt(c,s,x+w/2-dp(s.length()*3.1f),y+dp(40),10,active?green:gray,true);if(active)box(c,x+w*.25f,y+dp(7),x+w*.75f,y+dp(10),2,accent);}

    void drawHome(Canvas c){
        txt(c,"Promoções perto de você",dp(18),dp(125),23,dark,true); txt(c,"Compare encartes. Monte sua lista. Economize.",dp(18),dp(149),12,gray,false);
        box(c,dp(18),dp(171),getWidth()-dp(18),dp(220),18,Color.WHITE); txt(c,"⌕  Buscar produto, marca ou mercado",dp(34),dp(202),13,gray,false);
        txt(c,"DESTAQUES NA SUA REGIÃO",dp(18),dp(256),11,gray,true);
        drawMarketCard(c,dp(18),dp(275),"Mercado Aurora","28 ofertas","1,2 km","Até 16 JUL",Color.rgb(232,247,238));
        drawMarketCard(c,dp(18),dp(385),"SuperMais","42 ofertas","2,8 km","Até 17 JUL",Color.rgb(238,243,255));
        drawMarketCard(c,dp(18),dp(495),"Rede Econômica","31 ofertas","3,1 km","Até 15 JUL",Color.rgb(255,246,228));
        pill(c,"SOU UM MERCADO",dp(18),getHeight()-dp(112),dp(156),green,Color.WHITE);
    }
    void drawMarketCard(Canvas c,float x,float y,String name,String offers,String km,String valid,int tint){
        box(c,x,y,getWidth()-dp(18),y+dp(92),18,Color.WHITE); box(c,x+dp(12),y+dp(12),x+dp(72),y+dp(72),16,tint); txt(c,"OF",x+dp(29),y+dp(49),16,green,true);
        txt(c,name,x+dp(86),y+dp(32),16,dark,true); txt(c,offers+"  •  "+km,x+dp(86),y+dp(54),12,gray,false); pill(c,valid,x+dp(86),y+dp(62),dp(98),Color.rgb(235,244,239),green);
    }

    void drawCatalog(Canvas c){
        txt(c,"Encartes digitais",dp(18),dp(125),23,dark,true); txt(c,"Toque em um item para adicionar à sua lista",dp(18),dp(149),12,gray,false);
        pill(c,"PDF ORIGINAL",dp(18),dp(169),dp(108),Color.WHITE,green); pill(c,"LISTA CLICÁVEL",dp(136),dp(169),dp(126),green,Color.WHITE);
        float y=dp(218); for(int i=0;i<products.size();i++){Product pr=products.get(i); drawProduct(c,pr,dp(18),y+i*dp(91),i);}
    }
    void drawProduct(Canvas c,Product pr,float x,float y,int i){
        box(c,x,y,getWidth()-dp(18),y+dp(76),18,Color.WHITE); box(c,x+dp(12),y+dp(12),x+dp(64),y+dp(64),15,Color.rgb(234,244,238)); txt(c,pr.tag.substring(0,Math.min(2,pr.tag.length())),x+dp(27),y+dp(44),12,green,true);
        txt(c,pr.name,x+dp(76),y+dp(28),14,dark,true); txt(c,pr.market+" • "+pr.distance,x+dp(76),y+dp(48),10,gray,false); txt(c,pr.price,getWidth()-dp(112),y+dp(31),15,green,true);
        box(c,getWidth()-dp(60),y+dp(38),getWidth()-dp(28),y+dp(68),15,list.contains(pr)?accent:green); txt(c,list.contains(pr)?"✓":"+",getWidth()-dp(50),y+dp(59),16,Color.WHITE,true);
    }

    void drawList(Canvas c){
        txt(c,"Minha lista",dp(18),dp(125),23,dark,true); txt(c,list.size()+" itens adicionados",dp(18),dp(149),12,gray,false);
        if(list.isEmpty()){box(c,dp(18),dp(185),getWidth()-dp(18),dp(360),24,Color.WHITE);txt(c,"Sua lista está vazia",dp(63),dp(246),20,dark,true);txt(c,"Abra um encarte e toque no + dos produtos.",dp(39),dp(281),12,gray,false);pill(c,"VER ENCARTES",dp(85),dp(310),dp(160),green,Color.WHITE);return;}
        float y=dp(180);int total=0;Map<String,Integer> marketTotals=new LinkedHashMap<>();
        for(Product pr:list){total+=pr.cents;marketTotals.put(pr.market,marketTotals.getOrDefault(pr.market,0)+pr.cents);box(c,dp(18),y,getWidth()-dp(18),y+dp(58),16,Color.WHITE);txt(c,pr.name,dp(32),y+dp(24),13,dark,true);txt(c,pr.market,dp(32),y+dp(43),10,gray,false);txt(c,pr.price,getWidth()-dp(100),y+dp(33),14,green,true);y+=dp(68);} 
        txt(c,"Total desta seleção",dp(18),y+dp(26),12,gray,true);txt(c,money(total),dp(18),y+dp(59),26,dark,true);pill(c,"COMPARAR MERCADOS",dp(18),y+dp(78),dp(192),green,Color.WHITE);
    }

    void drawCompare(Canvas c){
        txt(c,"Comparar minha lista",dp(18),dp(125),23,dark,true); txt(c,"Estimativa usando ofertas digitalizadas",dp(18),dp(149),12,gray,false);
        compareCard(c,dp(18),dp(184),"1º","Rede Econômica","R$ 72,40","9,1 km","MELHOR PREÇO",Color.rgb(232,247,238));
        compareCard(c,dp(18),dp(306),"2º","SuperMais","R$ 76,90","4,2 km","+ R$ 4,50",Color.rgb(242,245,243));
        compareCard(c,dp(18),dp(428),"3º","Mercado Aurora","R$ 83,20","1,2 km","+ R$ 10,80",Color.rgb(242,245,243));
        box(c,dp(18),dp(570),getWidth()-dp(18),dp(660),20,Color.rgb(234,244,238));txt(c,"INSIGHT DE ECONOMIA",dp(34),dp(598),10,green,true);txt(c,"Você economiza R$ 10,80 indo",dp(34),dp(625),15,dark,true);txt(c,"7,9 km mais longe.",dp(34),dp(647),15,dark,true);
    }
    void compareCard(Canvas c,float x,float y,String pos,String name,String price,String km,String tag,int tint){box(c,x,y,getWidth()-dp(18),y+dp(104),20,Color.WHITE);box(c,x+dp(12),y+dp(15),x+dp(54),y+dp(57),14,tint);txt(c,pos,x+dp(23),y+dp(42),13,green,true);txt(c,name,x+dp(68),y+dp(30),15,dark,true);txt(c,km,x+dp(68),y+dp(51),11,gray,false);txt(c,price,getWidth()-dp(125),y+dp(36),18,green,true);pill(c,tag,x+dp(68),y+dp(65),dp(122),tint,green);}

    void drawMarket(Canvas c){
        txt(c,"Subir novo encarte",dp(18),dp(125),23,dark,true);txt(c,"Transforme seu PDF em ofertas clicáveis",dp(18),dp(149),12,gray,false);
        box(c,dp(18),dp(181),getWidth()-dp(18),dp(338),24,Color.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(Color.rgb(185,204,194));c.drawRoundRect(dp(32),dp(197),getWidth()-dp(32),dp(322),dp(18),dp(18),p);p.setStyle(Paint.Style.FILL);
        txt(c,pdfSelected?"PDF SELECIONADO":"TOQUE PARA SELECIONAR PDF",dp(52),dp(238),12,pdfSelected?green:gray,true);txt(c,pdfSelected?pdfName:"PDF do encarte promocional",dp(52),dp(265),14,dark,true);txt(c,"OCR + identificação de produtos + preços",dp(52),dp(289),11,gray,false);
        pill(c,"DIGITALIZAR ENCARTE",dp(18),dp(360),dp(204),pdfSelected?green:Color.rgb(188,197,192),Color.WHITE);
        txt(c,"PLANO DO MERCADO",dp(18),dp(428),11,gray,true);box(c,dp(18),dp(447),getWidth()-dp(18),dp(552),22,green);txt(c,"R$ 599",dp(35),dp(488),28,Color.WHITE,true);txt(c,"/ mês por mercado",dp(145),dp(488),13,Color.rgb(188,220,205),false);pill(c,"60 DIAS GRÁTIS",dp(35),dp(505),dp(132),Color.rgb(33,92,67),Color.WHITE);txt(c,"Sem taxa de implantação no piloto",dp(35),dp(546),11,Color.rgb(188,220,205),false);
        box(c,dp(18),dp(575),getWidth()-dp(18),dp(652),20,Color.WHITE);txt(c,"BI DE ENGAJAMENTO",dp(34),dp(604),11,green,true);txt(c,"Cliques por item • região • ranking de interesse",dp(34),dp(631),12,dark,true);
    }

    void drawBI(Canvas c){
        txt(c,"BI do encarte",dp(18),dp(125),23,dark,true);txt(c,"Período: 01–13 JUL • Mercado Aurora",dp(18),dp(149),12,gray,false);
        metric(c,dp(18),dp(180),"18,4 mil","IMPRESSÕES");metric(c,getWidth()/2+dp(4),dp(180),"2.130","CLIQUES EM ITENS");
        metric(c,dp(18),dp(267),"742","ADIÇÕES À LISTA");metric(c,getWidth()/2+dp(4),dp(267),"34,8%","TAXA DE INTERESSE");
        txt(c,"ITENS MAIS CLICADOS",dp(18),dp(385),11,gray,true);
        biBar(c,dp(18),dp(410),"Coca-Cola 2L","684 cliques",.92f);biBar(c,dp(18),dp(472),"Arroz Tio João 5kg","511 cliques",.72f);biBar(c,dp(18),dp(534),"Café Pilão 500g","402 cliques",.56f);
        txt(c,"REGIÕES COM MAIS INTERESSE",dp(18),dp(626),11,gray,true);box(c,dp(18),dp(645),getWidth()-dp(18),dp(712),18,Color.WHITE);txt(c,"Curitiba Centro  41%   •   Portão  24%",dp(32),dp(674),12,dark,true);txt(c,"Água Verde  19%   •   outras  16%",dp(32),dp(697),12,gray,false);
    }
    void metric(Canvas c,float x,float y,String val,String lab){float w=getWidth()/2-dp(27);box(c,x,y,x+w,y+dp(72),18,Color.WHITE);txt(c,val,x+dp(15),y+dp(31),21,dark,true);txt(c,lab,x+dp(15),y+dp(54),9,gray,true);}
    void biBar(Canvas c,float x,float y,String name,String clicks,float pct){box(c,x,y,getWidth()-dp(18),y+dp(50),16,Color.WHITE);txt(c,name,x+dp(14),y+dp(20),12,dark,true);txt(c,clicks,getWidth()-dp(104),y+dp(20),10,gray,true);box(c,x+dp(14),y+dp(31),getWidth()-dp(32),y+dp(38),4,Color.rgb(227,234,230));box(c,x+dp(14),y+dp(31),x+dp(14)+(getWidth()-dp(64))*pct,y+dp(38),4,accent);}

    String money(int cents){return String.format(Locale.forLanguageTag("pt-BR"),"R$ %.2f",cents/100.0).replace('.',',');}

    @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();float bottom=getHeight()-dp(68);
        if(y>bottom){if(marketMode){int idx=(int)(x/(getWidth()/3f)); if(idx==0)screen=4; else if(idx==1)screen=5; else {marketMode=false;screen=0;}}else{screen=(int)(x/(getWidth()/4f));}invalidate();return true;}
        if(!marketMode && screen==0 && y>getHeight()-dp(125)){marketMode=true;screen=4;invalidate();return true;}
        if(!marketMode && screen==1){float start=dp(218);int idx=(int)((y-start)/dp(91));if(idx>=0&&idx<products.size()){Product pr=products.get(idx);if(list.contains(pr))list.remove(pr);else list.add(pr);invalidate();return true;}}
        if(!marketMode && screen==2 && list.isEmpty() && y>dp(290)&&y<dp(360)){screen=1;invalidate();return true;}
        if(!marketMode && screen==2 && !list.isEmpty() && y>dp(500)){screen=3;invalidate();return true;}
        if(marketMode && screen==4 && y>dp(197)&&y<dp(338)){activity.pickPdf();return true;}
        if(marketMode && screen==4 && y>dp(350)&&y<dp(410)){if(!pdfSelected){Toast.makeText(activity,"Selecione um PDF primeiro",Toast.LENGTH_SHORT).show();}else{Toast.makeText(activity,"MVP: digitalização simulada. Itens identificados e publicados.",Toast.LENGTH_LONG).show();pdfSelected=false;}invalidate();return true;}
        return true;}
}

class Product {
    String name, price, market, distance, tag; int cents;
    Product(String n,String p,String m,String d,String t,int c){name=n;price=p;market=m;distance=d;tag=t;cents=c;}
}
class Hit { String label; int value; Hit(String l,int v){label=l;value=v;} }
